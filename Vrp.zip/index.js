const express = require('express');
const app = express();
app.get("/", (request, response) => {
  const ping = new Date();
  ping.setHours(ping.getHours() - 3);
  console.log(`Ping recebido às ${ping.getUTCHours()}:${ping.getUTCMinutes()}:${ping.getUTCSeconds()}`);
  response.sendStatus(200);
});
app.listen(process.env.PORT); // Recebe solicitações que o deixa online
const Aoijs = require("aoi.js")

const bot = new Aoijs.Bot({
  shardAmount: 2, 
  mobile: false, 

  token: "NzY2Mzg4OTAzMzY3OTMzOTg0.GguHPp.t-eiGO8tzXrp3_np55Ycpy3ozvWyWSQLukUlhc", 
  prefix: [":","%","*"], 
  autoUpdate: false
})

bot.onMessage() 
bot.loadCommands(`./commands/`) 

bot.variables({
  prefix:"*",
  ip:"nao definido",
  warn:"0",
  sug:""
  })
bot.status({
  text: "Brasíl Arevolution Life !!!...",
  type: "PLAYING",
  time: 12
})
bot.status({
  text: "Melhor Server Samp!!...",
  type: "PLAYING",
  time: 12
})
bot.status({
  text: "Mande uma Sugestão Usando *su...",
  type: "PLAYING",
  time: 12
})
bot.command({
name: "ping", 
code: `Pong! \`$ping\`` 
})

bot.command({
  name: "<@766388903367933984>",
  nonPrefixed: true,
  code: `
  Olá, <@$authorID>
$description[
$color[RANDOM]
$author[CHAMOU??]
\`
 Eu Sou o bot Oficial do Server, 
Use: *help para ver meus comandos
\`]`
 
})