module.exports = ({
  name:"help",
  aliases:['ajuda'],
  code:`

$description[
$author[🚩 > Comandos]
$addField[👤 | Moderação; 

\`
|| Ban || || Mute || || Kick ||

|| unmute || || unban || || clear ||

|| lock || unlock || || Av || setip ||

\`

]

$addField[👥 | Música/Outros; 
\`

|| play || || skip ||

|| resume || || pause ||

|| Su || || Ip ||

\`]

$footer[Comandos ajuda]
$color[RANDOM]
$Thumbnail[$servericon]

]
`
})