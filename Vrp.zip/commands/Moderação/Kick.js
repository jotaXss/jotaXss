module.exports = ({
 name: "kick",
 code: `
$kick[$mentioned[1]]
$description[$username[$mentioned[1]] 🚩 | Kikado Com Sucesso!!]
$color[BLUE]
$sendDM[$mentioned[1];❌| Você foi expulso do servidor: $serverName[$guildID]] 
$onlyIf[$rolePosition[$highestRole[$clientID]]<$rolePosition[$highestRole[$mentioned[1]]];🚫| Esse usuario e superior Igual a mim, Nao posso Kickar o Usuario.¡¡ ]
$onlyIf[$rolePosition[$highestRole[$authorID]]<$rolePosition[$highestRole[$mentioned[1]]];🚫| Esse Usuario e Suoerior a Você, Nao posso kickar esse esse usuario.]
$onlyIf[$mentioned[1]!=$authorID; erro fatal :3 ]
$onlyIf[$mentioned[1]!=;<@$authorId>, 🚫 | Vc Nao pode Kickar a Si mesmo.]
$onlyPerms[kick;{title:🚫 | Erro}{color:RANDOM}{description:Vc nao Tem permição para usar esse comando!! }]
$suppressErrors[ Ocorreu um erro , Tente mas tarde]`
 })
