module.exports = ({
name: "mute",
code: `
$channelSendMessage[$channelID;<@$mentioned[1]> Ja se passou o tempo be o Usuário foi Desmutado.]
$takeRoles[$mentioned[1];$roleID[Silenciado]]
$wait[$replaceText[$replaceText[$checkCondition[$noMentionMessage[1]==];true;24d];false;$noMentionMessage[1]]]
$channelSendMessage[$channelID;{description:✅ | $username[$mentioned[1]]#$discriminator[$mentioned[1]] Mutado com Sucesso \`$replaceText[$replaceText[$checkCondition[$noMentionMessage[1]==];true;Tempo de mute não definido];false;$noMentionMessage[1]]\`}{color:RANDOM}]
$giveRoles[$mentioned[1];$roleID[Silenciado]]
$onlyIf[$rolePosition[$highestRole[$clientID]]<$rolePosition[$highestRole[$mentioned[1]]];O Cargo do Usuario e maior que o meu]
$onlyIf[$rolePosition[$highestRole[$authorID]]<$rolePosition[$highestRole[$mentioned[1]]];O Cargo do Usuario e maior que o meu.]
$onlyIf[$mentioned[1]!=$authorID;Não tenho permição pra mutar esse usuario]
$onlyIf[$mentioned[1]!=;Mencione alguem para mutar.]
$onlyPerms[managemessages;{title:Sem permição}{color:RANDOM}{description:Não tem permição para usar esse comando}]`
})
