module.exports = ({
  name:"ip",
  code:`
$description[
$title[🚩 |Ip Copiavel]
$color[RANDOM]
$Thumbnail[$servericon]
\`
$getServerVar[ip]
\`
$footer[Clique No Ip e Segure Para Copiar !]
]
$deleteCommand
`
})