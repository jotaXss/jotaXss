module.exports = ({
name: "unban",
code:`

$unban[$noMentionMessage]Desbanido Com Sucesso
$suppressErrors[mencione o id do usuário ] 
$onlyPerms[ban;Você não tem permiçao para usar esse comando] 
`
})
