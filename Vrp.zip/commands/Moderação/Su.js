module.exports = ({
  name:"su",
  code:`
  $useChannel[$getServerVar[sug]]
 
  $description[
    $color[#ffff00]
    $author[🚩 |NOVA SUGESTÃO!]
    $message
    $footer[ Use  *su  para enviar  sua Sugestão]
    $addReactions[✅;❌]
    $deletecommand
    Sugestão de $username
$thumbnail[$servericon]
$addTimestamp
$channelSendMessage[$channelID;{description: 🚩 |Sua Sugestão Enviada!! }{author:| ENVIADA |}{color:RANDOM}{footer: Enviada}]
$argsCheck[>1;
{color:RANDOM}{title:🔴| ERRO}
{description:🟥| Escreva Uma sugestao valida para ser enviada Ex
\`<*Su> <Sua sugestao>\`}
    

    ]
  ]
$suppressErrors[\`🔴 | A sugestão Nao Foi enviada,é Nescessário a Setagem de Um canal de Sugestão\`]

  `
})