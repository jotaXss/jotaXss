module.exports = {
	name: 'ban',
	code: `
$ban[$mentioned[1]]
$channelSendMessage[$channelID;{title:🚩 Banimento!}{color:RANDOM}{footer: Id do Usuário| $userid}{description:✅ | $username Foi banido por  $username[$mentioned[1]]$discriminator[$mentioned[1]]}]
$onlyIf[$rolePosition[$highestRole[$clientID]]<$rolePosition[$highestRole[$mentioned[1]]];<@$authorId>, Não tenho permição para banir esse usuari]
$onlyIf[$rolePosition[$highestRole[$authorID]]<$rolePosition[$highestRole[$mentioned[1]]]; <@$authorId>, O cargo do usuario e maior que o meu ]
$onlyIf[$mentioned[1]!=$authorID;<@authorId>, Erro a o Banir]
$onlyIf[$mentioned[1]!=;<@$authorId>, Mencione algúem para banir .]
$onlyPerms[ban;{title:SEM PERMIÇÃO}{color:RANDOM}{description:<@$authorId>,  Sem permição para usar esse comando}]`
};
