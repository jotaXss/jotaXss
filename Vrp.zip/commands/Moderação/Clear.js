module.exports = ({
name: "clear",
 aliases: ['limpar'],
code: `
$clear[$message]  🟢 | $message Mensagens deletadas
$deleteIn[3s]
$onlyPerms[managemessages;Vc Esta sem permição para Apagar Mensagens.]
$onlyBotPerms[managemessages;Eu não tenho permição para Apagar Mensagens .]
$suppressErrors[Diga Um Numero Valido de mensagens de 1 a 100.]`
})
