module.exports = ({
 name: "unmute",
 code: `
$takeRoles[$mentioned[1];$roleID[Silenciado]]
$channelSendMessage[$channelID;{description:🟢 | $username[$mentioned[1]]#$discriminator[$mentioned[1]] Desmutado com Sucesso }]
$onlyIf[$mentioned[1]!=;Mencione AlguÃ©m Para Dar Unmute .]
$onlyPerms[managemessages;{title:🟥| Error}{color:RANDOM}{description: Voce nao tem Permissão Pra Isso }]
`
 })
