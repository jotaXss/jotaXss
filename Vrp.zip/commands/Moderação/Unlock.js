module.exports = ({
name: "unlock",
code: `
$modifyChannelPerms[$splitText[1];+sendmessages;$guildID]
<#$splitText[1]> Canal Desbloqueado com sucesso!
$textSplit[$replaceText[$replaceText[$checkCondition[$mentionedChannels[1]==];true;$channelID];false;$mentionedChannels[1]];/]
$onlyBotPerms[managechannels;❌ Eu nao posso usar esse comando! {delete:30s}]
$onlyPerms[managechannels;❌ | Vc nao tem a permiçao para usar esse comando! {delete:30s}]`})
