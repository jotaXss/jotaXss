module.exports = ({
  name:"setip",
  code:`
$author[Novo Ip Setado!]
$color[RANDOM]
$description[Novo Ip: $message[1]
$setServerVar[ip;$message]
$argsCheck[>1; <@$authorId>, Diga Um Ip para Ser Setado, O ip aparecerá no *ip]
]
$deleteCommand
$onlyperms[managemessages;<@$authorId>, 🟥 > Sem Permissão!!!]
`
})