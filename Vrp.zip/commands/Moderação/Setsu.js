module.exports = ({
  name:"setSugCanal",
  aliases: ['SuCanal'],
  code: `
$setServerVar[sug;$mentionedChannels[1]]
$description[
$color[RANDON]
$footer[Canal de Sugestão]
$addTimestamp
$author[⚙️ | Canal Setado!!!!]
Canal de Sugestão Setado Com Sucesso !!!

]
$channelSendMessage[$channelID;
$argsCheck[>1;{author: 🔴 | Erro}{description:  Use da forma Correta!!! >setSugcanal <canal>{footer:Erro De Juvenil}{color:RANDON}]
$onlyPerms[managemessages;🔴 |  Falta Poder pra Vc Zica!!!!]]

`
  
  
})