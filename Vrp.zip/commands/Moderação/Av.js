module.exports = ({
  name:"av",
  code: `
$description[
$author[🚩 | Aviso!!]
$color[RANDOM]
$addTimestamp
$footer[Aviso!!]
$Thumbnail[$servericon]
\`
$message
\`
$deleteCommand
$onlyPerms[admin; <@$authorId> Vc nao e Adm!!!]
$argscheck[>1; <@$authorId>, Coloque Uma mensagem para ser enviada em formato de aviso!!!]
]
`
})