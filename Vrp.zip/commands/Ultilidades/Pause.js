module.exports = ({
  name: "pause",
  aliases: ['pausar'],
  code: `
$description[
$title[Pausada]
\`🔈 | Voce Pausou a Música\`

$pauseSong
$suppressErrors[Erro Conectar em uma call e Nescessário!!]
]`
})