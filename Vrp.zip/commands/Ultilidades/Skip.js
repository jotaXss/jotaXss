module.exports = ({
  name: "skip",
  aliases: ['pular'],
  code: `
$descriptin[

\`⏭️ | Musica Pulada! \`

$skipSong
$suppressErrors[Erro Conectar em uma call e Nescessário!!]
]
`
})