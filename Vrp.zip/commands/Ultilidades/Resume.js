module.exports = ({
  name: "resume",
  code:`



$description[

\`🔈 | Musica Pausada\`



$resumeSong

]
$suppressErrors[Conectar em uma Call Obrigario, Para Pular A Musica]
`
})