module.exports = ({
  name: "play",
  aliases: ['p','tocar'],
  code: ` 

$description[\`🎶 | Música Tocando 
$playSong[$message;:x:]\`

$color[RANDOM]    
$title[Música]
$footer[Curte o Som] 
$deleteCommand
$argsCheck[>1; \`Fale O nome da Música\`]
$suppressErrors[Conecte-se a Um Canal de Voz Para executar o Cmd]

`

    
  })